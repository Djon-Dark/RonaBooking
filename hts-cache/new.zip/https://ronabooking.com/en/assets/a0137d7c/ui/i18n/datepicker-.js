<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-160202092-1"></script>
  <script>
      window.dataLayer = window.dataLayer || [];

      function gtag() {
          dataLayer.push(arguments);
      }

      gtag('js', new Date());

      gtag('config', 'UA-160202092-1');
  </script>


  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name='title' content="#1 Prices | Book your holiday in Croatia | Rona Booking"/>
    <meta name='description'
          content="Book your ideal Holiday in Croatia. Rent apartments in Istria, Kvarner, or on Croatian islands. Find the perfect Croatian holiday spot for your family/friends"/>
    <meta name='keywords'
          content='book croatian apartments, croatian holiday, holiday booking in coratia, holiday in istria, holiday in kvarner, holiday on croatian islands, book camping houses in croatia, rental management vacation rental yielding pms cleaning housekeeping reception'/>

    <link rel="icon" type="image/png" href="/favicon-32x32.png" sizes="32x32"/>
  <link rel="icon" type="image/png" href="/favicon-16x16.png" sizes="16x16"/>
  <title>Error</title>
  <!-- Bootstrap -->
  <link rel="stylesheet" href="/assets/Plugins/bootstrap-4.3.1-dist/css/bootstrap.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
  <!-- Font google -->
  <link href="https://fonts.googleapis.com/css?family=Barlow+Condensed:300,400,500,700&display=swap&subset=latin-ext"
        rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Fira+Sans+Extra+Condensed:300,500&display=swap&subset=latin-ext"
        rel="stylesheet">
  <!-- jQuery -->
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <!-- CSS -->
  <link rel="stylesheet" href="/assets/SCSS/main.css">



    <link href="/assets/a0137d7c/themes/smoothness/jquery-ui.css" rel="stylesheet">
<link href="/assets/CSS/main.css" rel="stylesheet">
<link href="/assets/CSS/ronabooking.css" rel="stylesheet">
<link href="/CSS/main_page_where_to_go.css" rel="stylesheet">
<script src="/assets/2cce3590/jquery.js"></script>
<script src="/assets/af9609c2/yii.js"></script>
<script src="/assets/a0137d7c/jquery-ui.js"></script>
<script src="/assets/JS/script.js"></script></head>

<body class="color-bg-blue-lagon">
<script>
    var LANGUAGE = "en";
    var LANG = "en";
    var canSleepMax = 20;
</script>

<!-- Header -->
<header class="error-header">
  <nav class="navbar navbar-expand-md navbar-dark nav-container">
    <a href="/" class="logo-desktop"><img src="/Images/Icons/rona-logo02.svg" alt=""></a>
    <a href="/" class="logo-mobile"><img src="/Images/Icons/rona-logo-mobile.svg"
                                         alt=""></a>
    <div class="form-input">
      <input type="text" placeholder="Search">
      <span><img src="/Images/Icons/search-icon.svg" alt=""></span>
    </div>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item sa-nav-item-filters">
          <a class="nav-link advanced-filters-link">Advanced filters</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="https://hosta.hr">Rent my place</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-partner-sign-up">Partner sign up</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-sign-up">Sign up</a>
        </li>
                      <li class="nav-item">
              <a class="nav-link nav-sign-in">Sign in</a>
            </li>
                </ul>
    </div>
  </nav>
  <div class="error-header__text-box">
    <div class="container">
      <div class="heading-primary">
        <div class="heading-primary-main">
            Error        </div>
        <div class="heading-primary-sub">
             Booking         </div>
        <div class="heading-primary-underline"></div>
        <div
            class="heading-primary-text">Something has gone wrong, please retrace your steps and try again.</div>
        <div class="heading-primary-button button-orange">
          <button class="btn" onclick="history.back()">
                            <span class="arrow-left">
                                <img src="/Images/Icons/arrow-left02.svg" alt="arrow left">
                            </span">Return back</button>
        </div>
      </div>
    </div>
  </div>
</header>
<!-- Footer -->
<footer class="footer position-fixed w-100 pos-b-0">
  <div class="bg-footer box-shadow-top">
    <div class="second-footer">
      <div class="second-footer-copyright">
        <div class="footer-sub">All rights RONA 2021</div>
        <span><i class="far fa-copyright"></i></span>
      </div>
      <div class="second-footer-lang-curr">
        <div class="second-footer-language">
          <div class="lang px-1 "><a
                style="color: #ffffff;" href="/sl/site/error">SI</a></div>
          <span class="white-line">-</span>
          <div class="lang px-1 "><a
                style="color: #ffffff;" href="/hr/site/error">HR</a></div>
          <span class="white-line">-</span>
          <div class="lang px-1 lang-active"><a
                style="color: #ffffff;" href="/en/site/error">EN</a></div>
          <span class="white-line">-</span>
          <div class="lang px-1 "><a
                style="color: #ffffff;" href="/de/site/error">DE</a></div>
          <span class="white-line">-</span>
          <div class="lang px-1 "><a
                style="color: #ffffff;" href="/ru/site/error">RU</a></div>
          <span class="white-line">-</span>
          <div class="lang px-1 "><a
                style="color: #ffffff;" href="/hu/site/error">HU</a></div>
        </div>
        <div class="second-footer-currency">
          <div class="currency px-1 cur-active">EUR</div>
          <span class="white-line">-</span>
          <div class="currency px-1">GBP</div>
          <span class="white-line">-</span>
          <div class="currency px-1">USD</div>
          <span class="white-line">-</span>
          <div class="currency px-1">HRK</div>
        </div>
      </div>
      <div class="second-footer-sidebar">
        <ul>
          <li><a
                href="https://www.facebook.com/infohosta.hr/?modal=composer&notif_id=1576079886226247&notif_t=aymt_upsell_tip&ref=notif"><i
                  class="fab fa-facebook-f"></i></a></li>
          <li><a href="#"><i class="fab fa-twitter"></i></a></li>
          <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          <li><a href="#"><i class="fab fa-youtube"></i></a></li>
          <li><a href="#"><i class="fab fa-google"></i></a></li>
        </ul>
      </div>
      <div class="second-footer-privacy-terms">
        <ul>
          <li><a href="#">Privacy policy</a></li>
          <li><a href="#">Terms & conditions</a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>
<!-- Javascript -->
<!--<script src="/assets/JS/script.js"></script>-->
<!--<script src="/assets/Plugins/bootstrap-4.3.1-dist/js/bootstrap.bundle.js"></script>-->
<!-- Language script -->
<script src='/assets/JS/Plugins/datepicker/datepicker-hr.js' type='text/javascript'></script>
<script src='/assets/JS/Plugins/datepicker/datepicker-ru.js' type='text/javascript'></script>
<script src='/assets/JS/Plugins/datepicker/datepicker-de.js' type='text/javascript'></script>
<script src='/assets/JS/Plugins/datepicker/datepicker-it.js' type='text/javascript'></script>
<script src='/assets/JS/Plugins/datepicker/datepicker-sl.js' type='text/javascript'></script>
<script src='/assets/JS/Plugins/datepicker/datepicker-hu.js' type='text/javascript'></script>
<script src='/assets/JS/Plugins/datepicker/datepicker-es.js' type='text/javascript'></script>
</body>
</html>
